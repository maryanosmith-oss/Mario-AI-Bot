import { Link } from "wouter";
import { AlertCircle } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground relative overflow-hidden">
      {/* Decorative background effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-destructive/5 blur-[120px] rounded-full pointer-events-none" />
      
      <div className="text-center space-y-6 relative z-10 px-4">
        <AlertCircle className="w-24 h-24 text-destructive mx-auto opacity-90 drop-shadow-[0_0_15px_rgba(255,0,0,0.3)]" />
        <h1 className="text-4xl md:text-6xl font-display font-bold tracking-tight text-white">
          404 <span className="text-muted-foreground font-light">|</span> Não Encontrado
        </h1>
        <p className="text-muted-foreground text-lg md:text-xl max-w-md mx-auto">
          A página que você está procurando foi movida, excluída ou possivelmente nunca existiu.
        </p>
        <div className="pt-8">
          <Link 
            href="/" 
            className={buttonVariants({ 
              size: "lg", 
              className: "font-semibold shadow-xl hover:-translate-y-0.5 transition-transform" 
            })}
          >
            Voltar ao Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
}
