import { BotLogEntry } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Terminal, Loader2, Users, User } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";

const LEVEL_STYLES: Record<string, string> = {
  info: "text-blue-400 bg-blue-400/10 border-blue-400/20",
  warn: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
  error: "text-red-400 bg-red-400/10 border-red-400/20",
  success: "text-primary bg-primary/10 border-primary/20",
};

export function LogsWidget({ logs, isLoading }: { logs?: BotLogEntry[], isLoading: boolean }) {
  return (
    <Card className="border-border/50 shadow-xl bg-card/60 backdrop-blur-md flex flex-col h-[500px]">
      <CardHeader className="border-b border-border/50 pb-4 shrink-0">
        <CardTitle className="text-xl font-display flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-muted-foreground" />
            Live Activity Feed
          </div>
          {isLoading && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 p-0 overflow-hidden">
        <ScrollArea className="h-full w-full p-4">
          <div className="flex flex-col gap-3 font-mono text-sm">
            <AnimatePresence initial={false}>
              {logs && logs.length > 0 ? (
                logs.map((log, index) => (
                  <motion.div
                    key={`${log.timestamp}-${index}`}
                    initial={{ opacity: 0, y: -10, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className="p-3 rounded-lg border border-border/40 bg-background/40 hover:bg-background/60 transition-colors"
                  >
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(log.timestamp), "HH:mm:ss", { locale: ptBR })}
                      </span>
                      <Badge variant="outline" className={`text-[10px] uppercase px-1.5 py-0 h-4 border ${LEVEL_STYLES[log.level]}`}>
                        {log.level}
                      </Badge>
                      {log.from && (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground/80 bg-black/20 px-2 py-0.5 rounded-full ml-auto">
                          {log.isGroup ? <Users className="w-3 h-3" /> : <User className="w-3 h-3" />}
                          <span className="truncate max-w-[120px]">{log.from}</span>
                        </div>
                      )}
                    </div>
                    <p className="text-foreground/90 leading-relaxed whitespace-pre-wrap break-words">
                      {log.message}
                    </p>
                  </motion.div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center h-full pt-12 text-muted-foreground">
                  <Terminal className="w-8 h-8 mb-2 opacity-20" />
                  <p>Aguardando logs do sistema...</p>
                </div>
              )}
            </AnimatePresence>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
