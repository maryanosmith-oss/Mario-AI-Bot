import { BotStatus, BotConfig } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Activity, Clock, MessageSquare, Smartphone, PowerOff, Loader2, Wrench } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

const STATE_COLORS: Record<string, string> = {
  ready: "bg-primary/20 text-primary border-primary/50",
  qr_ready: "bg-yellow-500/20 text-yellow-500 border-yellow-500/50",
  initializing: "bg-blue-500/20 text-blue-400 border-blue-500/50",
  authenticated: "bg-teal-500/20 text-teal-400 border-teal-500/50",
  disconnected: "bg-destructive/20 text-destructive border-destructive/50",
  auth_failure: "bg-red-600/20 text-red-500 border-red-600/50",
};

const STATE_LABELS: Record<string, string> = {
  ready: "Online",
  qr_ready: "Aguardando QR Code",
  initializing: "Inicializando...",
  authenticated: "Autenticado",
  disconnected: "Desconectado",
  auth_failure: "Falha na Autenticação",
};

const MODE_LABELS: Record<string, string> = {
  commands: "🔧 Apenas Comandos",
  auto: "🤖 Auto-resposta IA",
  both: "⚡ Comandos + IA",
};

export function StatusWidget({
  status,
  config,
  isLoading,
  onDisconnect,
  isDisconnecting,
}: {
  status?: BotStatus;
  config?: BotConfig;
  isLoading: boolean;
  onDisconnect: () => void;
  isDisconnecting: boolean;
}) {
  const currentState = status?.state || "disconnected";
  const canDisconnect = currentState !== "disconnected" && currentState !== "initializing";

  return (
    <Card className="border-border/50 shadow-xl bg-card/60 backdrop-blur-md relative overflow-hidden transition-all duration-300 hover:shadow-primary/5">
      <div className="absolute top-0 right-0 p-32 bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
      
      <CardHeader className="pb-4 border-b border-border/50">
        <CardTitle className="text-xl font-display flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" />
            <span>Status da Conexão</span>
          </div>
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
          ) : (
            <Badge 
              variant="outline" 
              className={`px-3 py-1 text-sm font-semibold transition-colors duration-300 ${STATE_COLORS[currentState]} ${currentState === 'ready' || currentState === 'initializing' ? 'animate-pulse' : ''}`}
            >
              {STATE_LABELS[currentState] || currentState}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="pt-6 space-y-6">
        <div className="grid grid-cols-1 gap-4">
          <div className="flex items-center p-3 rounded-xl bg-background/50 border border-border/50 hover:border-border transition-colors">
            <div className="p-2 rounded-lg bg-primary/10 text-primary mr-4">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Número Conectado</p>
              <p className="text-lg font-semibold text-foreground">
                {status?.phoneNumber || "Nenhum número"}
              </p>
            </div>
          </div>

          <div className="flex items-center p-3 rounded-xl bg-background/50 border border-border/50 hover:border-border transition-colors">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 mr-4">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Modo de Operação</p>
              <p className="text-lg font-semibold text-foreground">
                {config?.mode ? MODE_LABELS[config.mode as string] || "Desconhecido" : "Carregando..."}
              </p>
            </div>
          </div>

          <div className="flex items-center p-3 rounded-xl bg-background/50 border border-border/50 hover:border-border transition-colors">
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 mr-4">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Mensagens Respondidas</p>
              <p className="text-lg font-semibold text-foreground">
                {status?.messagesHandled || 0}
              </p>
            </div>
          </div>

          <div className="flex items-center p-3 rounded-xl bg-background/50 border border-border/50 hover:border-border transition-colors">
            <div className="p-2 rounded-lg bg-yellow-500/10 text-yellow-500 mr-4">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-muted-foreground">Tempo de Atividade</p>
              <p className="text-base font-semibold text-foreground capitalize">
                {status?.connectedAt 
                  ? formatDistanceToNow(new Date(status.connectedAt), { locale: ptBR })
                  : "Desconectado"
                }
              </p>
            </div>
          </div>
        </div>

        {canDisconnect && (
          <Button 
            variant="destructive" 
            className="w-full font-semibold shadow-lg shadow-destructive/20 hover:shadow-destructive/40 transition-all"
            onClick={onDisconnect}
            disabled={isDisconnecting}
          >
            {isDisconnecting ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <PowerOff className="w-4 h-4 mr-2" />
            )}
            Desconectar Bot
          </Button>
        )}
      </CardContent>
    </Card>
  );
}