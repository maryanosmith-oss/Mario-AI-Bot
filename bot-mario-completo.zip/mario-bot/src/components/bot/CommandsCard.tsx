import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Terminal, Shield, Smile, Download, Wrench, Coins, Bot, Crown, Star } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";

const categories = [
  {
    icon: Crown,
    label: "Administração",
    color: "text-yellow-400",
    bg: "bg-yellow-400/10 border-yellow-400/30",
    commands: [
      { cmd: "ban @user", desc: "Bane usuário do grupo" },
      { cmd: "kick @user", desc: "Remove usuário do grupo" },
      { cmd: "add número", desc: "Adiciona número ao grupo" },
      { cmd: "promote @user", desc: "Promove a admin" },
      { cmd: "demote @user", desc: "Rebaixa de admin" },
      { cmd: "mute / unmute", desc: "Silencia ou abre o grupo" },
      { cmd: "grupo fechar/abrir", desc: "Fecha ou abre o grupo" },
      { cmd: "linkgp", desc: "Mostra link do grupo" },
      { cmd: "resetlink", desc: "Reseta o link do grupo" },
      { cmd: "marcar [msg]", desc: "Marca todos os membros" },
      { cmd: "hidetag [msg]", desc: "Marca todos (invisible)" },
    ],
  },
  {
    icon: Shield,
    label: "Proteção",
    color: "text-blue-400",
    bg: "bg-blue-400/10 border-blue-400/30",
    commands: [
      { cmd: "antispam on/off", desc: "Anti-flood de mensagens" },
      { cmd: "antitrava on/off", desc: "Bloqueia mensagens bugadas" },
      { cmd: "antilink on/off", desc: "Remove links de não-admin" },
      { cmd: "antifake on/off", desc: "Bloqueia números falsos" },
      { cmd: "antipalavrao on/off", desc: "Filtra palavrões" },
      { cmd: "welcome on/off [msg] [url]", desc: "Boas-vindas com mídia" },
    ],
  },
  {
    icon: Star,
    label: "Figurinhas",
    color: "text-pink-400",
    bg: "bg-pink-400/10 border-pink-400/30",
    commands: [
      { cmd: "sticker / s", desc: "Imagem/vídeo → figurinha" },
      { cmd: "toimg", desc: "Figurinha → imagem" },
      { cmd: "ttp <texto>", desc: "Texto → figurinha" },
      { cmd: "attp <texto>", desc: "Texto colorido → figurinha" },
      { cmd: "roubar", desc: "Copia figurinha de resposta" },
    ],
  },
  {
    icon: Bot,
    label: "Inteligência Artificial",
    color: "text-green-400",
    bg: "bg-green-400/10 border-green-400/30",
    commands: [
      { cmd: "ia / chat / gpt <pergunta>", desc: "Pergunta à IA" },
      { cmd: "img <prompt>", desc: "Gera imagem com IA (DALL-E)" },
      { cmd: "tts / voz <texto>", desc: "Converte texto em áudio" },
    ],
  },
  {
    icon: Download,
    label: "Downloads",
    color: "text-orange-400",
    bg: "bg-orange-400/10 border-orange-400/30",
    commands: [
      { cmd: "play <nome>", desc: "Baixa música do YouTube" },
      { cmd: "ytmp3 <link>", desc: "YouTube → áudio MP3" },
      { cmd: "ytmp4 <link>", desc: "YouTube → vídeo MP4" },
      { cmd: "tiktok <link>", desc: "Baixa vídeo do TikTok" },
      { cmd: "instagram <link>", desc: "Baixa do Instagram" },
      { cmd: "facebook <link>", desc: "Baixa do Facebook" },
    ],
  },
  {
    icon: Smile,
    label: "Diversão & Jogos",
    color: "text-purple-400",
    bg: "bg-purple-400/10 border-purple-400/30",
    commands: [
      { cmd: "dado [lados]", desc: "Rola um dado" },
      { cmd: "cassino <valor>", desc: "Joga no caça-níquel" },
      { cmd: "roleta [aposta]", desc: "Joga na roleta" },
      { cmd: "ppt pedra|papel|tesoura", desc: "Jokenpo contra o bot" },
      { cmd: "quiz", desc: "Trivia de perguntas" },
      { cmd: "ship @u1 @u2", desc: "Calcula compatibilidade" },
      { cmd: "casal", desc: "Sorteia casal do dia" },
      { cmd: "rank / level / xp", desc: "Sistema de experiência" },
    ],
  },
  {
    icon: Coins,
    label: "Economia",
    color: "text-emerald-400",
    bg: "bg-emerald-400/10 border-emerald-400/30",
    commands: [
      { cmd: "saldo", desc: "Veja suas moedas" },
      { cmd: "daily", desc: "Recompensa diária" },
      { cmd: "work", desc: "Trabalhe para ganhar moedas" },
      { cmd: "transfer @user <val>", desc: "Transfere moedas" },
      { cmd: "bank dep/saq <val>", desc: "Banco pessoal" },
    ],
  },
  {
    icon: Wrench,
    label: "Utilidades",
    color: "text-cyan-400",
    bg: "bg-cyan-400/10 border-cyan-400/30",
    commands: [
      { cmd: "clima <cidade>", desc: "Clima atual de qualquer cidade" },
      { cmd: "hora", desc: "Horário do Brasil" },
      { cmd: "calc <expressão>", desc: "Calculadora" },
      { cmd: "cep <número>", desc: "Consulta endereço por CEP" },
      { cmd: "traduz <texto>", desc: "Traduz para português" },
      { cmd: "google <pesquisa>", desc: "Link de busca no Google" },
      { cmd: "wiki <termo>", desc: "Busca na Wikipedia PT" },
      { cmd: "ping", desc: "Latência do bot" },
      { cmd: "info", desc: "Info do grupo ou chat" },
      { cmd: "postar", desc: "Posta mídia com legenda" },
    ],
  },
];

export function CommandsCard({ mode, prefix }: { mode?: string; prefix?: string }) {
  if (mode === "auto") return null;
  const p = prefix || "!";
  const [openCategory, setOpenCategory] = useState<string | null>("Administração");

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="border-border/50 shadow-xl bg-card/60 backdrop-blur-md">
        <CardHeader className="border-b border-border/50 pb-4">
          <CardTitle className="text-xl font-display flex items-center gap-2">
            <Terminal className="w-5 h-5 text-primary" />
            Comandos Disponíveis
          </CardTitle>
          <CardDescription>
            {Object.values(categories).reduce((a, c) => a + c.commands.length, 0)}+ comandos organizados por categoria.
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-4 space-y-2">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isOpen = openCategory === cat.label;
            return (
              <div key={cat.label} className={`rounded-xl border ${isOpen ? cat.bg : "border-border/30 bg-background/30"} transition-all overflow-hidden`}>
                <button
                  onClick={() => setOpenCategory(isOpen ? null : cat.label)}
                  className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-white/5 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Icon className={`w-4 h-4 ${cat.color}`} />
                    <span className={`font-semibold text-sm ${isOpen ? cat.color : "text-foreground"}`}>{cat.label}</span>
                    <span className="text-xs text-muted-foreground bg-muted/50 px-1.5 py-0.5 rounded-full">{cat.commands.length}</span>
                  </div>
                  <span className={`text-muted-foreground text-xs transition-transform ${isOpen ? "rotate-180" : ""}`}>▼</span>
                </button>
                {isOpen && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 px-4 pb-4">
                    {cat.commands.map((c) => (
                      <div key={c.cmd} className="flex flex-col p-2.5 rounded-lg bg-background/50 border border-border/30 hover:border-primary/40 hover:bg-primary/5 transition-all">
                        <code className={`${cat.color} font-mono font-bold text-xs mb-0.5 tracking-tight`}>{p}{c.cmd}</code>
                        <span className="text-xs text-muted-foreground">{c.desc}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </CardContent>
      </Card>
    </motion.div>
  );
}
