import OpenAI from "openai";
import { logger } from "../lib/logger";

const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY || "dummy",
});

export async function generateAIResponse(
  userMessage: string,
  contactName: string,
  groupName: string | null,
  systemPrompt: string,
  botName: string,
): Promise<string> {
  try {
    const contextMessage = groupName
      ? `Você está em um grupo chamado "${groupName}". O usuário "${contactName}" disse:`
      : `O usuário "${contactName}" disse:`;

    const response = await openai.chat.completions.create({
      model: "gpt-5-mini",
      max_completion_tokens: 500,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `${contextMessage}\n\n${userMessage}` },
      ],
    });

    const content = response.choices[0]?.message?.content;
    if (!content) throw new Error("Empty response from AI");
    return content.trim();
  } catch (err: unknown) {
    logger.error({ err }, "AI response error");
    return `Oi! Sou ${botName} e no momento estou com dificuldades técnicas. Tenta de novo em instantes! 😊`;
  }
}

export async function generateImage(prompt: string): Promise<string | null> {
  try {
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt,
      n: 1,
      size: "1024x1024",
    });
    return response.data?.[0]?.url || null;
  } catch (err) {
    logger.error({ err }, "Image generation error");
    return null;
  }
}

export async function generateTTS(text: string): Promise<Buffer | null> {
  try {
    const response = await openai.audio.speech.create({
      model: "tts-1",
      voice: "nova",
      input: text.substring(0, 4096),
    });
    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  } catch (err) {
    logger.error({ err }, "TTS error");
    return null;
  }
}
