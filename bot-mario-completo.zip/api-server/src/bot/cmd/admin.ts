import { GroupChat, GroupParticipant } from "whatsapp-web.js";
import { CommandContext } from "../commands";
import { getGroup, saveGroup } from "../db";
import { toggleProtection } from "../protection";
import { setWelcome, setWelcomeMessage, setWelcomeMediaBase64, clearWelcomeMedia } from "../welcome";
import {
  toggleModeration, flipModeration, setAllModeration, ModerationFeature,
  setWarnLimit, resetUserWarnings, resetAllWarnings, getWarnInfo,
} from "../moderation";
import { agendarFechargp, agendarAbrirgp, listarAgendamentos, cancelarAgendamento } from "../schedule";

async function requireGroup(ctx: CommandContext): Promise<GroupChat | null> {
  if (!ctx.isGroup) {
    await ctx.msg.reply("❌ Este comando só funciona em grupos!");
    return null;
  }
  return ctx.chat as GroupChat;
}

async function findParticipant(
  ctx: CommandContext,
  participants: GroupParticipant[],
): Promise<GroupParticipant | undefined> {
  const senderId = ctx.senderId;
  const senderUser = senderId.split("@")[0];

  // 1) Tentativa direta: compara ID serializado ou a parte numérica
  let p = participants.find(
    (p) => p.id._serialized === senderId || p.id.user === senderUser,
  );
  if (p) return p;

  // 2) Fallback: usa o número de telefone do contato (resolve LID → número real)
  try {
    const contact = await ctx.msg.getContact();
    const phone = contact.number || contact.id?.user;
    if (phone) {
      p = participants.find(
        (p) =>
          p.id.user === phone ||
          p.id._serialized === `${phone}@c.us` ||
          p.id._serialized === `${phone}@s.whatsapp.net`,
      );
    }
  } catch {}

  return p;
}

async function requireAdmin(ctx: CommandContext, group: GroupChat): Promise<boolean> {
  const participants = group.participants;
  const sender = await findParticipant(ctx, participants);
  const isAdmin = sender?.isAdmin || sender?.isSuperAdmin || false;

  if (!isAdmin) {
    await ctx.msg.reply(
      "🚫 Apenas *admins do grupo* podem usar este comando!",
    );
    return false;
  }
  return true;
}

export async function cmdBan(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;

  const mentions = await ctx.msg.getMentions();
  if (!mentions.length) {
    await ctx.msg.reply("❓ Use: !ban @usuario");
    return;
  }

  const participants = group.participants;
  let count = 0;
  const results: string[] = [];

  for (const c of mentions) {
    const targetParticipant = participants.find(
      (p) =>
        p.id._serialized === c.id._serialized || p.id.user === c.id.user,
    );
    if (targetParticipant?.isAdmin || targetParticipant?.isSuperAdmin) {
      results.push(`⚠️ ${c.pushname || c.number} é admin — não pode ser banido`);
      continue;
    }
    try {
      await group.removeParticipants([c.id._serialized]);
      count++;
      results.push(`✅ ${c.pushname || c.number} removido`);
      ctx.addLog(
        "warn",
        `🚫 ${c.pushname || c.number} banido por ${ctx.contactName}`,
        ctx.contactName,
        true,
      );
    } catch {
      results.push(`❌ Erro ao banir ${c.pushname || c.number}`);
    }
  }

  await ctx.msg.reply(
    `🔨 *Resultado do ban:*\n\n${results.join("\n")}\n\n${count > 0 ? `✅ ${count} membro(s) removido(s)` : "❌ Nenhum membro foi removido"}`,
  );
}

export async function cmdKick(ctx: CommandContext) {
  return cmdBan(ctx);
}

export async function cmdAdd(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const number = ctx.args[0]?.replace(/[^0-9]/g, "");
  if (!number) {
    await ctx.msg.reply("❓ Use: !add 5511999999999");
    return;
  }
  try {
    await group.addParticipants([`${number}@c.us`]);
    await ctx.msg.reply(`✅ ${number} adicionado ao grupo!`);
  } catch {
    await ctx.msg.reply(`❌ Não foi possível adicionar ${number}.`);
  }
}

export async function cmdPromote(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const mentions = await ctx.msg.getMentions();
  if (!mentions.length) {
    await ctx.msg.reply("❓ Use: !promote @usuario");
    return;
  }
  for (const c of mentions) {
    try {
      await group.promoteParticipants([c.id._serialized]);
    } catch {}
  }
  await ctx.msg.reply(`✅ Usuário(s) promovido(s) a admin!`);
}

export async function cmdDemote(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const mentions = await ctx.msg.getMentions();
  if (!mentions.length) {
    await ctx.msg.reply("❓ Use: !demote @usuario");
    return;
  }
  for (const c of mentions) {
    try {
      await group.demoteParticipants([c.id._serialized]);
    } catch {}
  }
  await ctx.msg.reply(`✅ Usuário(s) rebaixado(s) a membro!`);
}

export async function cmdMute(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  try {
    await group.setMessagesAdminsOnly(true);
    await ctx.msg.reply("🔇 Grupo *mutado*! Apenas admins podem enviar mensagens.");
    const g = getGroup(group.id._serialized);
    g.muted = true;
    saveGroup(g);
  } catch {
    await ctx.msg.reply("❌ Erro ao mutar. O bot precisa ser admin do grupo!");
  }
}

export async function cmdUnmute(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  try {
    await group.setMessagesAdminsOnly(false);
    await ctx.msg.reply("🔊 Grupo *aberto*! Todos podem enviar mensagens.");
    const g = getGroup(group.id._serialized);
    g.muted = false;
    saveGroup(g);
  } catch {
    await ctx.msg.reply("❌ Erro ao desmutar. O bot precisa ser admin do grupo!");
  }
}

export async function cmdGrupo(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const action = ctx.args[0]?.toLowerCase();
  if (action === "fechar") {
    try {
      await group.setMessagesAdminsOnly(true);
      await ctx.msg.reply("🔒 Grupo *fechado*! Apenas admins podem enviar.");
    } catch {
      await ctx.msg.reply("❌ O bot precisa ser admin para fechar o grupo.");
    }
  } else if (action === "abrir") {
    try {
      await group.setMessagesAdminsOnly(false);
      await ctx.msg.reply("🔓 Grupo *aberto*! Todos podem enviar.");
    } catch {
      await ctx.msg.reply("❌ O bot precisa ser admin para abrir o grupo.");
    }
  } else {
    await ctx.msg.reply("❓ Use: *!grupo abrir* ou *!grupo fechar*");
  }
}

export async function cmdLinkgp(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  try {
    const code = await group.getInviteCode();
    await ctx.msg.reply(`🔗 *Link do grupo:*\nhttps://chat.whatsapp.com/${code}`);
  } catch {
    await ctx.msg.reply("❌ O bot precisa ser admin para pegar o link.");
  }
}

export async function cmdResetlink(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  try {
    await group.revokeInvite();
    const newCode = await group.getInviteCode();
    await ctx.msg.reply(`✅ *Link resetado!*\nhttps://chat.whatsapp.com/${newCode}`);
  } catch {
    await ctx.msg.reply("❌ O bot precisa ser admin para resetar o link.");
  }
}

export async function cmdMarcar(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const msgText = ctx.argString || "📢 Atenção a todos!";
  const participants = group.participants;
  const mentions: any[] = [];
  const tags: string[] = [];
  for (const p of participants) {
    try {
      const contact = await ctx.chat.client.getContactById(p.id._serialized);
      mentions.push(contact);
      tags.push(`@${p.id.user}`);
    } catch {}
  }
  await group.sendMessage(`${msgText}\n\n${tags.join(" ")}`, { mentions });
}

export async function cmdHidetag(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const msgText = ctx.argString || "📢";
  const participants = group.participants;
  const mentions: any[] = [];
  for (const p of participants) {
    try {
      const contact = await ctx.chat.client.getContactById(p.id._serialized);
      mentions.push(contact);
    } catch {}
  }
  await group.sendMessage(msgText, { mentions });
}

export async function cmdAntispam(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const val = ctx.args[0]?.toLowerCase() === "on";
  toggleProtection(group.id._serialized, "antispam", val);
  await ctx.msg.reply(`✅ Anti-spam *${val ? "ATIVADO 🟢" : "DESATIVADO 🔴"}*!`);
}

export async function cmdAntitrava(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const val = ctx.args[0]?.toLowerCase() === "on";
  toggleProtection(group.id._serialized, "antitrava", val);
  await ctx.msg.reply(`✅ Anti-trava *${val ? "ATIVADO 🟢" : "DESATIVADO 🔴"}*!`);
}

export async function cmdAntilink(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const val = ctx.args[0]?.toLowerCase() === "on";
  toggleProtection(group.id._serialized, "antilink", val);
  await ctx.msg.reply(`✅ Anti-link *${val ? "ATIVADO 🟢" : "DESATIVADO 🔴"}*!`);
}

export async function cmdAntifake(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const val = ctx.args[0]?.toLowerCase() === "on";
  toggleProtection(group.id._serialized, "antifake", val);
  await ctx.msg.reply(`✅ Anti-fake *${val ? "ATIVADO 🟢" : "DESATIVADO 🔴"}*!`);
}

export async function cmdAntipalavrao(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const val = ctx.args[0]?.toLowerCase() === "on";
  toggleProtection(group.id._serialized, "antipalavrao", val);
  await ctx.msg.reply(`✅ Anti-palavrão *${val ? "ATIVADO 🟢" : "DESATIVADO 🔴"}*!`);
}

export async function cmdWelcome(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;

  const subCmd = ctx.args[0]?.toLowerCase();

  // ── !welcome off ──────────────────────────────────────────────────────────
  if (subCmd === "off") {
    setWelcome(group.id._serialized, false);
    await ctx.msg.reply("✅ *Boas-vindas DESATIVADO! 🔴*");
    return;
  }

  // ── !welcome limpar ───────────────────────────────────────────────────────
  if (subCmd === "limpar" || subCmd === "clear") {
    clearWelcomeMedia(group.id._serialized);
    await ctx.msg.reply("🗑️ *Imagem de boas-vindas removida!*\nPróximas boas-vindas serão apenas texto.");
    return;
  }

  // ── !welcome ver ──────────────────────────────────────────────────────────
  if (subCmd === "ver" || subCmd === "info") {
    const g = getGroup(group.id._serialized);
    const temImagem = !!(g.welcomeMediaBase64 || g.welcomeMedia);
    const status = g.welcome ? "🟢 ATIVO" : "🔴 INATIVO";
    await ctx.msg.reply(
      `📋 *Configuração de Boas-vindas*\n\n` +
      `Status: ${status}\n` +
      `Imagem: ${temImagem ? "✅ configurada" : "❌ sem imagem"}\n` +
      `Mensagem:\n_${g.welcomeMsg}_\n\n` +
      `💡 *@user* é substituído pelo nome do novo membro.`,
    );
    return;
  }

  // ── !welcome on [texto] (com ou sem imagem anexada) ───────────────────────
  if (subCmd !== "on") {
    await ctx.msg.reply(
      `❓ *Como usar o comando !welcome:*\n\n` +
      `*Ativar com imagem da galeria:*\n` +
      `→ Envie a imagem com a legenda:\n` +
      `  \`!welcome on Bem-vindo @user! 🎉\`\n\n` +
      `*Ativar só com texto:*\n` +
      `  \`!welcome on Olá @user, seja bem-vindo!\`\n\n` +
      `*Desativar:*\n  \`!welcome off\`\n\n` +
      `*Remover imagem:*\n  \`!welcome limpar\`\n\n` +
      `*Ver configuração atual:*\n  \`!welcome ver\`\n\n` +
      `💡 *@user* → nome do novo membro\n` +
      `💡 *{grupo}* → nome do grupo`,
    );
    return;
  }

  // Ativa boas-vindas
  setWelcome(group.id._serialized, true);

  // Texto personalizado (args após "on")
  const textoRaw = ctx.args.slice(1).join(" ").trim();

  // Extrai URL de imagem se houver no texto
  const urlMatch = textoRaw.match(/https?:\/\/\S+/);
  const mediaUrl = urlMatch?.[0] ?? null;
  const textoLimpo = textoRaw.replace(urlMatch?.[0] ?? "", "").trim();
  const textoFinal = textoLimpo || "👋 Bem-vindo(a) ao grupo, @user! 🎉\n\nFique à vontade! 😊";

  // Salva o texto (e URL legado se houver)
  setWelcomeMessage(group.id._serialized, textoFinal, mediaUrl ?? undefined);

  // ── Detecta imagem: primeiro verifica a própria mensagem, depois quoted ──
  let imagemSalva = false;

  const tryDownload = async (msgComMidia: any): Promise<boolean> => {
    try {
      const media = await msgComMidia.downloadMedia();
      if (media?.data && media.mimetype?.startsWith("image/")) {
        setWelcomeMediaBase64(group.id._serialized, media.data, media.mimetype);
        return true;
      }
    } catch {}
    return false;
  };

  // 1) Imagem anexada diretamente ao comando
  if (ctx.msg.hasMedia) {
    imagemSalva = await tryDownload(ctx.msg);
  }

  // 2) Imagem em mensagem respondida (quoted)
  if (!imagemSalva && ctx.msg.hasQuotedMsg) {
    try {
      const quoted = await ctx.msg.getQuotedMessage();
      if (quoted.hasMedia) {
        imagemSalva = await tryDownload(quoted);
      }
    } catch {}
  }

  // ── Resposta de confirmação ───────────────────────────────────────────────
  const linhaImagem = imagemSalva
    ? "🖼️ Imagem salva da galeria ✅"
    : mediaUrl
      ? `🔗 URL de imagem salva ✅`
      : "💬 Apenas texto (sem imagem)";

  await ctx.msg.reply(
    `✅ *Boas-vindas ATIVADO! 🟢*\n\n` +
    `${linhaImagem}\n` +
    `📝 Mensagem:\n_${textoFinal}_\n\n` +
    `💡 *@user* será substituído pelo nome do novo membro.\n` +
    `💡 Para remover a imagem: \`!welcome limpar\`\n` +
    `💡 Para desativar: \`!welcome off\``,
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS DE MODERAÇÃO
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Fábrica de comandos de moderação com toggle inteligente:
 *  • Sem argumento   → inverte o estado atual (toggle)
 *  • Argumento "on"  → ativa
 *  • Argumento "off" → desativa
 */
function makeModCmd(feature: ModerationFeature, label: string) {
  return async (ctx: CommandContext) => {
    const group = await requireGroup(ctx);
    if (!group || !(await requireAdmin(ctx, group))) return;

    const arg = ctx.args[0]?.toLowerCase();
    let newVal: boolean;

    if (arg === "on" || arg === "ativar" || arg === "ligar") {
      newVal = true;
      toggleModeration(group.id._serialized, feature, newVal);
    } else if (arg === "off" || arg === "desativar" || arg === "desligar") {
      newVal = false;
      toggleModeration(group.id._serialized, feature, newVal);
    } else {
      // Sem argumento → toggle automático
      newVal = flipModeration(group.id._serialized, feature);
    }

    await ctx.msg.reply(
      newVal
        ? `✅ *${label} ATIVADO!* 🟢\nO sistema está ativo e monitorando o grupo.`
        : `❌ *${label} DESATIVADO!* 🔴\nO sistema foi desligado.`,
    );
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// COMANDOS DE MODERAÇÃO — gerados pelo helper
// ─────────────────────────────────────────────────────────────────────────────

export const cmdAntivirus         = makeModCmd("antivirus",                "Anti-vírus");
export const cmdAntiimagem        = makeModCmd("antiimagem",               "Anti-imagem");
export const cmdAntiaudio         = makeModCmd("antiaudio",                "Anti-áudio");
export const cmdAntilocalizacao   = makeModCmd("antilocalizacao",          "Anti-localização");
export const cmdAntilinkgp        = makeModCmd("antilinkgp",               "Anti-link de grupo WhatsApp");
export const cmdAntigif           = makeModCmd("antigif",                  "Anti-GIF");
export const cmdAntifigurinha     = makeModCmd("antifigurinha",            "Anti-figurinha");
export const cmdAntipalavraomod   = makeModCmd("antipalavraomod",          "Anti-palavrão avançado");
export const cmdAntipalavraoaudio = makeModCmd("antipalavraoaudio",        "Anti-palavrão em áudio");
export const cmdAntipalavraovideo = makeModCmd("antipalavraovideo",        "Anti-palavrão em vídeo");
export const cmdAntipornografiatexto        = makeModCmd("antipornografiatexto",        "Anti-pornografia em texto");
export const cmdAntipornografiaimagem       = makeModCmd("antipornografiaimagem",       "Anti-pornografia em imagem");
export const cmdAntipornografiavideo        = makeModCmd("antipornografiavideo",        "Anti-pornografia em vídeo");
export const cmdAntipornografiaaudio        = makeModCmd("antipornografiaaudio",        "Anti-pornografia em áudio");
export const cmdAntipornografiagif          = makeModCmd("antipornografiagif",          "Anti-pornografia em GIF");
export const cmdAntifigurinhapornografica   = makeModCmd("antifigurinhapornografica",   "Anti-figurinha pornográfica");
export const cmdAutofig           = makeModCmd("autofig",                  "Auto-figurinha");

// ─────────────────────────────────────────────────────────────────────────────
// COMANDOS GLOBAIS: ATIVAR/DESATIVAR TODOS OS SISTEMAS DE UMA VEZ
// ─────────────────────────────────────────────────────────────────────────────

export async function cmdAtivartodos(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;

  setAllModeration(group.id._serialized, true);

  await ctx.msg.reply(
    `🟢 *TODOS OS SISTEMAS ATIVADOS!*\n\n` +
    `✅ Anti-vírus\n` +
    `✅ Anti-imagem\n` +
    `✅ Anti-áudio\n` +
    `✅ Anti-localização\n` +
    `✅ Anti-link de grupo\n` +
    `✅ Anti-GIF\n` +
    `✅ Anti-figurinha\n` +
    `✅ Anti-palavrão (texto)\n` +
    `✅ Anti-palavrão (áudio)\n` +
    `✅ Anti-palavrão (vídeo)\n` +
    `✅ Anti-pornografia (texto)\n` +
    `✅ Anti-pornografia (imagem)\n` +
    `✅ Anti-pornografia (vídeo)\n` +
    `✅ Anti-pornografia (áudio)\n` +
    `✅ Anti-pornografia (GIF)\n` +
    `✅ Anti-figurinha pornográfica\n` +
    `✅ Auto-figurinha\n\n` +
    `🛡️ O grupo está com *proteção máxima* ativada!\n` +
    `Use \`!modstatus\` para ver o status detalhado.`,
  );
}

export async function cmdDesativartodos(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;

  setAllModeration(group.id._serialized, false);

  await ctx.msg.reply(
    `🛑 *TODOS OS SISTEMAS DESATIVADOS!*\n\n` +
    `❌ Anti-vírus\n` +
    `❌ Anti-imagem\n` +
    `❌ Anti-áudio\n` +
    `❌ Anti-localização\n` +
    `❌ Anti-link de grupo\n` +
    `❌ Anti-GIF\n` +
    `❌ Anti-figurinha\n` +
    `❌ Anti-palavrão (texto)\n` +
    `❌ Anti-palavrão (áudio)\n` +
    `❌ Anti-palavrão (vídeo)\n` +
    `❌ Anti-pornografia (texto)\n` +
    `❌ Anti-pornografia (imagem)\n` +
    `❌ Anti-pornografia (vídeo)\n` +
    `❌ Anti-pornografia (áudio)\n` +
    `❌ Anti-pornografia (GIF)\n` +
    `❌ Anti-figurinha pornográfica\n` +
    `❌ Auto-figurinha\n\n` +
    `⚠️ Todos os sistemas de proteção foram desligados.\n` +
    `Use \`!ativartodos\` para religar tudo de uma vez.`,
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SISTEMA DE ADVERTÊNCIAS
// ─────────────────────────────────────────────────────────────────────────────

export async function cmdSetadv(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const n = parseInt(ctx.args[0] ?? "");
  if (isNaN(n) || n < 1 || n > 20) {
    await ctx.msg.reply("❓ Use: *!setadv <número>* (1–20)\nEx: !setadv 3");
    return;
  }
  setWarnLimit(group.id._serialized, n);
  await ctx.msg.reply(`✅ Limite de advertências definido: *${n} avisos* antes da remoção!`);
}

export async function cmdResetadv(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;

  const sub = ctx.args[0]?.toLowerCase();
  if (sub === "all" || sub === "todos") {
    resetAllWarnings(group.id._serialized);
    await ctx.msg.reply("✅ *Todas as advertências resetadas!*");
    return;
  }

  const mentions = await ctx.msg.getMentions();
  if (!mentions.length) {
    await ctx.msg.reply("❓ Use:\n• *!resetadv @usuário* — resetar avisos de um membro\n• *!resetadv all* — resetar todos");
    return;
  }
  for (const c of mentions) {
    resetUserWarnings(group.id._serialized, c.id._serialized);
  }
  await ctx.msg.reply(`✅ Advertências resetadas para ${mentions.length} usuário(s)!`);
}

export async function cmdAdv(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group) return;

  const mentions = await ctx.msg.getMentions();
  if (mentions.length) {
    const lines = mentions.map((c) => {
      const { count, limit } = getWarnInfo(group.id._serialized, c.id._serialized);
      return `• @${c.id.user}: *${count}/${limit}* avisos`;
    });
    await ctx.msg.reply(`⚠️ *Advertências:*\n\n${lines.join("\n")}`);
  } else {
    const { count, limit } = getWarnInfo(group.id._serialized, ctx.senderId);
    await ctx.msg.reply(`⚠️ Seus avisos: *${count}/${limit}*`);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// AGENDAMENTO DE GRUPO (comandos !fechargp / !abrirgp)
// ─────────────────────────────────────────────────────────────────────────────

export async function cmdFechargp(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const horario = ctx.args[0];
  if (!horario) {
    await ctx.msg.reply("❓ Use: *!fechargp HH:MM*\nEx: !fechargp 22:00");
    return;
  }
  const result = agendarFechargp(group.id._serialized, horario);
  await ctx.msg.reply(result);
}

export async function cmdAbrirgp(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const horario = ctx.args[0];
  if (!horario) {
    await ctx.msg.reply("❓ Use: *!abrirgp HH:MM*\nEx: !abrirgp 08:00");
    return;
  }
  const result = agendarAbrirgp(group.id._serialized, horario);
  await ctx.msg.reply(result);
}

export async function cmdAgendamentos(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group) return;
  const result = listarAgendamentos(group.id._serialized);
  await ctx.msg.reply(result);
}

export async function cmdCancelarAg(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group || !(await requireAdmin(ctx, group))) return;
  const idx = parseInt(ctx.args[0] ?? "");
  if (isNaN(idx)) {
    await ctx.msg.reply("❓ Use: *!cancedag <número>*\nVeja os números com !agendamentos");
    return;
  }
  const result = cancelarAgendamento(group.id._serialized, idx);
  await ctx.msg.reply(result);
}

// ─────────────────────────────────────────────────────────────────────────────
// STATUS DE MODERAÇÃO DO GRUPO
// ─────────────────────────────────────────────────────────────────────────────

export async function cmdModstatus(ctx: CommandContext) {
  const group = await requireGroup(ctx);
  if (!group) return;
  const g = getGroup(group.id._serialized);
  const on = "🟢"; const off = "🔴";
  const s = (v: boolean) => v ? on : off;
  await ctx.msg.reply(
    `🛡️ *Status de Moderação — ${group.name}*\n\n` +
    `*[PROTEÇÃO EXISTENTE]*\n` +
    `${s(g.antispam)} Anti-spam\n` +
    `${s(g.antitrava)} Anti-trava\n` +
    `${s(g.antilink)} Anti-link\n` +
    `${s(g.antifake)} Anti-fake\n` +
    `${s(g.antipalavrao)} Anti-palavrão (básico)\n\n` +
    `*[MODERAÇÃO AVANÇADA]*\n` +
    `${s(g.antivirus)} Anti-vírus\n` +
    `${s(g.antiimagem)} Anti-imagem\n` +
    `${s(g.antiaudio)} Anti-áudio\n` +
    `${s(g.antilocalizacao)} Anti-localização\n` +
    `${s(g.antilinkgp)} Anti-link de grupo WA\n` +
    `${s(g.antigif)} Anti-GIF\n` +
    `${s(g.antifigurinha)} Anti-figurinha\n` +
    `${s(g.antipalavraomod)} Anti-palavrão avançado\n` +
    `${s(g.antipalavraoaudio)} Anti-palavrão áudio\n` +
    `${s(g.antipalavraovideo)} Anti-palavrão vídeo\n\n` +
    `*[ANTI-PORNOGRAFIA]*\n` +
    `${s(g.antipornografiatexto)} Texto\n` +
    `${s(g.antipornografiaimagem)} Imagem\n` +
    `${s(g.antipornografiavideo)} Vídeo\n` +
    `${s(g.antipornografiaaudio)} Áudio\n` +
    `${s(g.antipornografiagif)} GIF\n` +
    `${s(g.antifigurinhapornografica)} Figurinha\n\n` +
    `*[EXTRAS]*\n` +
    `${s(g.autofig)} Auto-figurinha\n\n` +
    `⚠️ Limite de avisos: *${g.warnLimit ?? 3}*`,
  );
}
