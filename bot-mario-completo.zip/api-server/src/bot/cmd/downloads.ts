import { CommandContext } from "../commands";
import { execFile } from "child_process";
import { promisify } from "util";
import { readFile, unlink } from "fs/promises";
import { join } from "path";
import { tmpdir } from "os";
import { MessageMedia } from "whatsapp-web.js";

const execFileAsync = promisify(execFile);

function findYtDlp(): string {
  return process.env.YTDLP_PATH || "yt-dlp";
}

export async function cmdYtmp3(ctx: CommandContext) {
  const url = ctx.args[0];
  if (!url || (!url.includes("youtube") && !url.includes("youtu.be"))) {
    await ctx.msg.reply(
      "❓ Use: !ytmp3 <link do YouTube>\nEx: !ytmp3 https://youtu.be/xxxxx",
    );
    return;
  }
  await ctx.msg.reply("⏳ Baixando áudio... aguarde!");
  const outPath = join(tmpdir(), `ytmp3_${Date.now()}.mp3`);
  try {
    await execFileAsync(
      findYtDlp(),
      [
        "-x",
        "--audio-format",
        "mp3",
        "--audio-quality",
        "0",
        "-o",
        outPath,
        "--no-playlist",
        "--max-filesize",
        "15M",
        url,
      ],
      { timeout: 60000 },
    );
    const data = await readFile(outPath);
    const media = new MessageMedia(
      "audio/mpeg",
      data.toString("base64"),
      "audio.mp3",
    );
    await ctx.chat.sendMessage(media, { sendAudioAsVoice: false });
    ctx.addLog("success", `🎵 YT MP3 baixado`, ctx.contactName, ctx.isGroup);
  } catch (err: any) {
    await ctx.msg.reply(
      `❌ Erro ao baixar: ${err.message?.substring(0, 100) || "Tente novamente"}`,
    );
  } finally {
    unlink(outPath).catch(() => {});
  }
}

export async function cmdYtmp4(ctx: CommandContext) {
  const url = ctx.args[0];
  if (!url || (!url.includes("youtube") && !url.includes("youtu.be"))) {
    await ctx.msg.reply(
      "❓ Use: !ytmp4 <link do YouTube>\nEx: !ytmp4 https://youtu.be/xxxxx",
    );
    return;
  }
  await ctx.msg.reply("⏳ Baixando vídeo... aguarde! (máx 15MB)");
  const outPath = join(tmpdir(), `ytmp4_${Date.now()}.mp4`);
  try {
    await execFileAsync(
      findYtDlp(),
      [
        "-f",
        "bestvideo[height<=480]+bestaudio/best[height<=480]",
        "--merge-output-format",
        "mp4",
        "-o",
        outPath,
        "--no-playlist",
        "--max-filesize",
        "15M",
        url,
      ],
      { timeout: 90000 },
    );
    const data = await readFile(outPath);
    const media = new MessageMedia(
      "video/mp4",
      data.toString("base64"),
      "video.mp4",
    );
    await ctx.chat.sendMessage(media);
    ctx.addLog("success", `🎬 YT MP4 baixado`, ctx.contactName, ctx.isGroup);
  } catch (err: any) {
    await ctx.msg.reply(
      `❌ Erro ao baixar vídeo: ${err.message?.substring(0, 100) || "Arquivo muito grande ou indisponível"}`,
    );
  } finally {
    unlink(outPath).catch(() => {});
  }
}

export async function cmdPlay(ctx: CommandContext) {
  const query = ctx.argString.trim();
  if (!query) {
    await ctx.msg.reply(
      "❓ Use: !play <nome da música>\nEx: !play Evidências Chitãozinho",
    );
    return;
  }
  await ctx.msg.reply(`🔍 Procurando: "${query}"...`);
  const outPath = join(tmpdir(), `play_${Date.now()}.mp3`);
  try {
    await execFileAsync(
      findYtDlp(),
      [
        `ytsearch1:${query}`,
        "-x",
        "--audio-format",
        "mp3",
        "--audio-quality",
        "2",
        "-o",
        outPath,
        "--no-playlist",
        "--max-filesize",
        "15M",
      ],
      { timeout: 60000 },
    );
    const data = await readFile(outPath);
    const media = new MessageMedia(
      "audio/mpeg",
      data.toString("base64"),
      `${query}.mp3`,
    );
    await ctx.chat.sendMessage(media, {
      sendAudioAsVoice: false,
      caption: `🎵 ${query}`,
    });
  } catch (err: any) {
    await ctx.msg.reply(`❌ Música não encontrada ou muito grande: "${query}"`);
  } finally {
    unlink(outPath).catch(() => {});
  }
}

export async function cmdTiktok(ctx: CommandContext) {
  const url = ctx.args[0];
  if (!url || !url.includes("tiktok")) {
    await ctx.msg.reply("❓ Use: !tiktok <link do TikTok>");
    return;
  }
  await ctx.msg.reply("⏳ Baixando TikTok...");
  const outPath = join(tmpdir(), `tiktok_${Date.now()}.mp4`);
  try {
    await execFileAsync(
      findYtDlp(),
      ["--no-check-certificate", "-o", outPath, url],
      { timeout: 60000 },
    );
    const data = await readFile(outPath);
    const media = new MessageMedia(
      "video/mp4",
      data.toString("base64"),
      "tiktok.mp4",
    );
    await ctx.chat.sendMessage(media);
  } catch {
    await ctx.msg.reply(
      "❌ Não foi possível baixar o TikTok. Verifique o link.",
    );
  } finally {
    unlink(outPath).catch(() => {});
  }
}

export async function cmdInstagram(ctx: CommandContext) {
  const url = ctx.args[0];
  if (!url || !url.includes("instagram")) {
    await ctx.msg.reply("❓ Use: !instagram <link do Instagram>");
    return;
  }
  await ctx.msg.reply("⏳ Baixando do Instagram...");
  const outPath = join(tmpdir(), `ig_${Date.now()}.mp4`);
  try {
    await execFileAsync(
      findYtDlp(),
      ["--no-check-certificate", "-o", outPath, url],
      { timeout: 60000 },
    );
    const data = await readFile(outPath);
    const media = new MessageMedia(
      "video/mp4",
      data.toString("base64"),
      "instagram.mp4",
    );
    await ctx.chat.sendMessage(media);
  } catch {
    await ctx.msg.reply(
      "❌ Não foi possível baixar. O perfil pode ser privado.",
    );
  } finally {
    unlink(outPath).catch(() => {});
  }
}

export async function cmdFacebook(ctx: CommandContext) {
  const url = ctx.args[0];
  if (!url || (!url.includes("facebook") && !url.includes("fb.watch"))) {
    await ctx.msg.reply("❓ Use: !facebook <link do Facebook>");
    return;
  }
  await ctx.msg.reply("⏳ Baixando do Facebook...");
  const outPath = join(tmpdir(), `fb_${Date.now()}.mp4`);
  try {
    await execFileAsync(
      findYtDlp(),
      ["--no-check-certificate", "-o", outPath, url],
      { timeout: 60000 },
    );
    const data = await readFile(outPath);
    const media = new MessageMedia(
      "video/mp4",
      data.toString("base64"),
      "facebook.mp4",
    );
    await ctx.chat.sendMessage(media);
  } catch {
    await ctx.msg.reply("❌ Não foi possível baixar o vídeo do Facebook.");
  } finally {
    unlink(outPath).catch(() => {});
  }
}
