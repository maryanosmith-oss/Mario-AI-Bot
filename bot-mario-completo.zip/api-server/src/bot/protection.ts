import { Message, GroupChat } from "whatsapp-web.js";
import { getGroup, saveGroup } from "./db";
import { logger } from "../lib/logger";

const URL_REGEX = /(?:https?|ftp):\/\/[\w\-]+(\.[\w\-]+)+[/#?]?/gi;
const HEAVY_UNICODE_REGEX = /[\u0300-\u036f\u1dc0-\u1dff\u20d0-\u20ff\ufe20-\ufe2f]{5,}/g;
const MAX_MSG_LENGTH = 2000;
const MAX_MEDIA_PER_MINUTE = 10;

const PALAVROES = [
  "caralho","puta","merda","porra","viado","cuzao","buceta","fdp",
  "viadao","filho da puta","arrombado","corno","piroca","punheta",
];

interface SpamEntry { count: number; firstTs: number; warned: boolean }
const spamMap = new Map<string, SpamEntry>();
const mediaFloodMap = new Map<string, number[]>();

export interface ProtectionResult {
  blocked: boolean;
  reason?: string;
  action?: "delete" | "warn" | "kick";
}

export async function checkProtection(
  msg: Message,
  chat: GroupChat,
  senderId: string,
): Promise<ProtectionResult> {
  const group = getGroup(chat.id._serialized);
  const body = msg.body || "";
  const now = Date.now();

  // senderId is the real sender (msg.author in groups, msg.from in private)
  const senderUser = senderId.split("@")[0];
  const participants = chat.participants;

  // Find participant — try direct ID match first, then phone-number fallback (handles LID format)
  let senderParticipant = participants.find(
    (p) => p.id._serialized === senderId || p.id.user === senderUser,
  );
  if (!senderParticipant) {
    try {
      const contact = await msg.getContact();
      const phone = contact.number || contact.id?.user;
      if (phone) {
        senderParticipant = participants.find(
          (p) =>
            p.id.user === phone ||
            p.id._serialized === `${phone}@c.us` ||
            p.id._serialized === `${phone}@s.whatsapp.net`,
        );
      }
    } catch {}
  }

  const isAdmin =
    senderParticipant?.isAdmin || senderParticipant?.isSuperAdmin || false;
  if (isAdmin) return { blocked: false };

  if (group.antitrava) {
    if (body.length > MAX_MSG_LENGTH) {
      return { blocked: true, reason: "Mensagem muito grande (anti-trava)", action: "delete" };
    }
    if (HEAVY_UNICODE_REGEX.test(body)) {
      return { blocked: true, reason: "Caracteres pesados detectados (anti-trava)", action: "delete" };
    }
    if (msg.hasMedia) {
      const key = `media_${senderId}`;
      const timestamps = mediaFloodMap.get(key) || [];
      const recent = timestamps.filter((t) => now - t < 60000);
      recent.push(now);
      mediaFloodMap.set(key, recent);
      if (recent.length > MAX_MEDIA_PER_MINUTE) {
        return { blocked: true, reason: "Flood de mídia (anti-trava)", action: "warn" };
      }
    }
  }

  if (group.antispam) {
    const key = senderId;
    const entry = spamMap.get(key) || { count: 0, firstTs: now, warned: false };
    if (now - entry.firstTs > 5000) {
      spamMap.set(key, { count: 1, firstTs: now, warned: false });
    } else {
      entry.count++;
      spamMap.set(key, entry);
      if (entry.count >= 8) {
        return { blocked: true, reason: "Spam detectado — removendo", action: "kick" };
      }
      if (entry.count >= 5 && !entry.warned) {
        entry.warned = true;
        return { blocked: true, reason: "⚠️ Anti-spam: mensagens rápidas detectadas. Diminua o ritmo!", action: "warn" };
      }
    }
  }

  if (group.antilink && URL_REGEX.test(body)) {
    return { blocked: true, reason: "Link detectado (anti-link)", action: "delete" };
  }

  if (group.antifake) {
    const numberStr = senderId.replace(/[^0-9]/g, "");
    if (numberStr.length < 10 || numberStr.length > 15) {
      return { blocked: true, reason: "Número inválido (anti-fake)", action: "kick" };
    }
  }

  if (group.antipalavrao) {
    const bodyLower = body.toLowerCase();
    const found = PALAVROES.find((p) => bodyLower.includes(p));
    if (found) {
      return { blocked: true, reason: `Palavrão detectado (anti-palavrao)`, action: "delete" };
    }
  }

  return { blocked: false };
}

export async function applyProtectionAction(
  msg: Message,
  chat: GroupChat,
  result: ProtectionResult,
  botIsAdmin: boolean,
): Promise<void> {
  try {
    if (result.action === "delete" && botIsAdmin) {
      try { await msg.delete(true); } catch {}
    }
    if (result.action === "warn") {
      await chat.sendMessage(`⚠️ @${msg.from.split("@")[0]}: ${result.reason}`, {
        mentions: [await msg.getContact()],
      });
    }
    if (result.action === "kick" && botIsAdmin) {
      try { await msg.delete(true); } catch {}
      await chat.sendMessage(`🚫 @${msg.from.split("@")[0]} foi removido: ${result.reason}`, {
        mentions: [await msg.getContact()],
      });
      await chat.removeParticipants([msg.from]);
    }
  } catch (err) {
    logger.error({ err }, "Error applying protection action");
  }
}

export function toggleProtection(
  groupId: string,
  feature: "antispam" | "antitrava" | "antilink" | "antifake" | "antipalavrao",
  value: boolean,
): void {
  const group = getGroup(groupId);
  group[feature] = value;
  saveGroup(group);
}
