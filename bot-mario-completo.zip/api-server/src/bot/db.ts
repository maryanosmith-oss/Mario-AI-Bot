import { readFileSync, writeFileSync, existsSync } from "fs";
import { join } from "path";

const DB_PATH = join("/tmp", "mario_bot_db.json");

export interface UserData {
  id: string;
  xp: number;
  level: number;
  coins: number;
  bank: number;
  lastDaily: number;
  lastWork: number;
  lastXp: number;
  totalMessages: number;
}

export interface GroupData {
  id: string;
  // ── Proteções existentes ────────────────────────────────────────────────
  antispam: boolean;
  antitrava: boolean;
  antilink: boolean;
  antifake: boolean;
  antipalavrao: boolean;
  // ── Boas-vindas ─────────────────────────────────────────────────────────
  welcome: boolean;
  welcomeMsg: string;
  welcomeMedia: string | null;
  welcomeMediaBase64: string | null;
  welcomeMediaMime: string | null;
  muted: boolean;
  // ── Moderação avançada (novos campos) ───────────────────────────────────
  antivirus: boolean;
  antiimagem: boolean;
  antiaudio: boolean;
  antilocalizacao: boolean;
  antilinkgp: boolean;
  antigif: boolean;
  antifigurinha: boolean;
  antipalavraomod: boolean;
  antipalavraoaudio: boolean;
  antipalavraovideo: boolean;
  antipornografiatexto: boolean;
  antipornografiaimagem: boolean;
  antipornografiavideo: boolean;
  antipornografiaaudio: boolean;
  antipornografiagif: boolean;
  antifigurinhapornografica: boolean;
  autofig: boolean;
  // ── Sistema de advertências ─────────────────────────────────────────────
  warnLimit: number;
  warnings: Record<string, number>;
}

export interface BotDatabase {
  users: Record<string, UserData>;
  groups: Record<string, GroupData>;
}

let _cache: BotDatabase | null = null;

function load(): BotDatabase {
  if (_cache) return _cache;
  if (existsSync(DB_PATH)) {
    try {
      _cache = JSON.parse(readFileSync(DB_PATH, "utf-8"));
      return _cache!;
    } catch {}
  }
  _cache = { users: {}, groups: {} };
  return _cache;
}

function save(): void {
  if (_cache) {
    try {
      writeFileSync(DB_PATH, JSON.stringify(_cache, null, 2));
    } catch {}
  }
}

export function getUser(id: string): UserData {
  const db = load();
  if (!db.users[id]) {
    db.users[id] = {
      id,
      xp: 0,
      level: 1,
      coins: 100,
      bank: 0,
      lastDaily: 0,
      lastWork: 0,
      lastXp: 0,
      totalMessages: 0,
    };
    save();
  }
  return db.users[id];
}

export function saveUser(user: UserData): void {
  const db = load();
  db.users[user.id] = user;
  save();
}

export function getGroup(id: string): GroupData {
  const db = load();
  if (!db.groups[id]) {
    db.groups[id] = {
      id,
      antispam: true,
      antitrava: true,
      antilink: false,
      antifake: false,
      antipalavrao: false,
      welcome: false,
      welcomeMsg: "👋 Bem-vindo(a) ao grupo, @user! 🎉",
      welcomeMedia: null,
      welcomeMediaBase64: null,
      welcomeMediaMime: null,
      muted: false,
      antivirus: false,
      antiimagem: false,
      antiaudio: false,
      antilocalizacao: false,
      antilinkgp: false,
      antigif: false,
      antifigurinha: false,
      antipalavraomod: false,
      antipalavraoaudio: false,
      antipalavraovideo: false,
      antipornografiatexto: false,
      antipornografiaimagem: false,
      antipornografiavideo: false,
      antipornografiaaudio: false,
      antipornografiagif: false,
      antifigurinhapornografica: false,
      autofig: false,
      warnLimit: 3,
      warnings: {},
    };
    save();
  }
  return db.groups[id];
}

export function saveGroup(group: GroupData): void {
  const db = load();
  db.groups[group.id] = group;
  save();
}

export function getAllUsers(): UserData[] {
  return Object.values(load().users);
}

export function addXp(userId: string, amount: number): { levelUp: boolean; newLevel: number } {
  const user = getUser(userId);
  const now = Date.now();
  if (now - user.lastXp < 30000) return { levelUp: false, newLevel: user.level };
  user.xp += amount;
  user.lastXp = now;
  user.totalMessages++;
  const newLevel = Math.floor(Math.sqrt(user.xp / 50)) + 1;
  const levelUp = newLevel > user.level;
  if (levelUp) user.level = newLevel;
  saveUser(user);
  return { levelUp, newLevel };
}

export function getLeaderboard(groupId?: string): UserData[] {
  return getAllUsers()
    .sort((a, b) => b.xp - a.xp)
    .slice(0, 10);
}
