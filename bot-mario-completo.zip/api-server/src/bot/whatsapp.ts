import { Client, LocalAuth, Message, GroupChat } from "whatsapp-web.js";
import { EventEmitter } from "events";
import { execSync } from "child_process";
import { logger } from "../lib/logger";
import { generateAIResponse } from "./ai";
import { handleCommand, checkQuizAnswer } from "./commands";
import { checkProtection, applyProtectionAction } from "./protection";
import { handleMemberJoin } from "./welcome";
import { addXp, getGroup } from "./db";
import { startGuardian } from "./guardian";
import { checkModeration, applyModeration, handleAutoFig } from "./moderation";

function findChromiumPath(): string {
  const env = process.env.CHROMIUM_PATH;
  if (env) return env;
  try {
    const path = execSync(
      "which chromium 2>/dev/null || which chromium-browser 2>/dev/null || which google-chrome 2>/dev/null",
      { encoding: "utf-8" },
    ).trim();
    if (path) return path;
  } catch {}
  return "/usr/bin/chromium";
}

export type BotState =
  | "initializing"
  | "qr_ready"
  | "authenticated"
  | "ready"
  | "disconnected"
  | "auth_failure";

export interface BotLogEntry {
  timestamp: string;
  level: "info" | "warn" | "error" | "success";
  message: string;
  from: string | null;
  isGroup: boolean | null;
}

export interface BotConfig {
  botName: string;
  systemPrompt: string;
  replyInGroups: boolean;
  antiSpamDelay: number;
  responseDelay: number;
  prefix: string;
  mode: "commands" | "auto" | "both";
}

class WhatsAppBot extends EventEmitter {
  private client: Client | null = null;
  private state: BotState = "initializing";
  private qrDataUrl: string | null = null;
  private phoneNumber: string | null = null;
  private connectedAt: string | null = null;
  private messagesHandled = 0;
  private logs: BotLogEntry[] = [];
  private spamTracker = new Map<string, number>();
  private isInitializing = false;
  private guardianStarted = false;
  private reconnectDelay = 15000; // backoff adaptativo
  private initStartedAt: number | null = null; // para detecção de init travado

  config: BotConfig = {
    botName: "MÁRIO",
    systemPrompt: `Você é MÁRIO, um assistente de WhatsApp amigável, inteligente e divertido que fala português brasileiro.
Responda de forma natural, humana e contextual.
Seja simpático, prestativo e adapte seu tom de acordo com a conversa.
Mantenha as respostas concisas mas completas.
Nunca mencione que é um bot ou IA, apenas responda como MÁRIO.`,
    replyInGroups: true,
    antiSpamDelay: 3000,
    responseDelay: 1500,
    prefix: "!",
    mode: "commands",
  };

  constructor() {
    super();
    this.addLog("info", "Bot MÁRIO inicializando...");
    this.initClient();
    // Guardian inicia junto com o bot, sem esperar o "ready"
    if (!this.guardianStarted) {
      this.guardianStarted = true;
      startGuardian(this);
    }
  }

  addLog(
    level: BotLogEntry["level"],
    message: string,
    from: string | null = null,
    isGroup: boolean | null = null,
  ) {
    const entry: BotLogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      from,
      isGroup,
    };
    this.logs.unshift(entry);
    if (this.logs.length > 200) this.logs.pop();
    logger.info({ level, message, from, isGroup }, "Bot log");
    this.emit("log", entry);
  }

  private initClient() {
    if (this.isInitializing) return;
    this.isInitializing = true;
    this.initStartedAt = Date.now();
    this.state = "initializing";
    this.qrDataUrl = null;

    this.client = new Client({
      authStrategy: new LocalAuth({ dataPath: "/tmp/wwebjs_auth" }),
      puppeteer: {
        headless: true,
        executablePath: findChromiumPath(),
        args: [
          "--no-sandbox",
          "--disable-setuid-sandbox",
          "--disable-dev-shm-usage",
          "--disable-accelerated-2d-canvas",
          "--no-first-run",
          "--no-zygote",
          "--single-process",
          "--disable-gpu",
          "--disable-extensions",
          "--disable-background-timer-throttling",
          "--disable-backgrounding-occluded-windows",
          "--disable-renderer-backgrounding",
        ],
      },
    });

    this.client.on("qr", async (qr) => {
      this.state = "qr_ready";
      this.addLog("info", "QR Code gerado. Escaneie para conectar!");
      try {
        const qrcode = await import("qrcode");
        this.qrDataUrl = await qrcode.default.toDataURL(qr, { width: 256, margin: 2 });
      } catch (err) {
        logger.error({ err }, "Failed to generate QR data URL");
      }
      this.emit("qr", this.qrDataUrl);
    });

    this.client.on("authenticated", () => {
      this.state = "authenticated";
      this.qrDataUrl = null;
      this.addLog("success", "Autenticado com sucesso!");
      this.emit("authenticated");
    });

    this.client.on("auth_failure", (msg) => {
      this.state = "auth_failure";
      this.isInitializing = false;
      this.addLog("error", `Falha de autenticação: ${msg}`);
      this.emit("auth_failure", msg);
      setTimeout(() => this.initClient(), 10000);
    });

    this.client.on("ready", async () => {
      this.state = "ready";
      this.isInitializing = false;
      this.reconnectDelay = 15000; // reseta backoff ao conectar com sucesso
      this.connectedAt = new Date().toISOString();
      try {
        const info = this.client?.info;
        if (info) this.phoneNumber = info.wid?.user ?? null;
      } catch {}
      this.addLog(
        "success",
        `✅ Bot MÁRIO ONLINE! ${this.phoneNumber ? `Número: ${this.phoneNumber}` : ""} | Modo: ${
          this.config.mode === "commands" ? `Comandos (${this.config.prefix})`
          : this.config.mode === "auto" ? "Auto-resposta" : "Comandos + Auto"
        }`,
      );
      this.emit("ready");
    });

    this.client.on("disconnected", (reason) => {
      this.state = "disconnected";
      this.isInitializing = false;
      // backoff adaptativo: dobra o delay a cada queda, máximo de 5 minutos
      const delay = this.reconnectDelay;
      this.reconnectDelay = Math.min(this.reconnectDelay * 2, 5 * 60 * 1000);
      this.addLog("warn", `Desconectado: ${reason}. Reconectando em ${delay / 1000}s...`);
      this.emit("disconnected", reason);
      setTimeout(() => this.initClient(), delay);
    });

    this.client.on("message", async (msg: Message) => {
      await this.handleMessage(msg);
    });

    this.client.on("group_join" as any, async (notification: any) => {
      await this.handleGroupJoin(notification);
    });

    this.addLog("info", "Iniciando cliente WhatsApp...");
    this.client.initialize().catch((err) => {
      this.isInitializing = false;
      this.addLog("error", `Erro ao inicializar: ${err.message}`);
      logger.error({ err }, "Failed to initialize WhatsApp client");
      setTimeout(() => this.initClient(), 30000);
    });
  }

  private async handleGroupJoin(notification: any) {
    try {
      const chat = await notification.getChat() as GroupChat;
      const groupId = chat.id._serialized;
      const participants = Array.isArray(notification.recipientIds)
        ? notification.recipientIds.map((id: string) => ({ id: { _serialized: id, user: id.split("@")[0] } }))
        : [];
      if (participants.length > 0) {
        await handleMemberJoin(chat, participants as any, groupId);
        this.addLog("info", `👋 Novo membro no grupo ${chat.name}`, null, true);
      }
    } catch (err) {
      logger.error({ err }, "Error handling group join");
    }
  }

  private async handleMessage(msg: Message) {
    try {
      if (msg.fromMe) return;

      const chat = await msg.getChat();
      const isGroup = chat.isGroup;

      if (isGroup && !this.config.replyInGroups) return;

      const body = msg.body?.trim() || "";

      // In group messages msg.from is the GROUP jid; the real sender is msg.author.
      // In private messages msg.from IS the sender (msg.author is undefined).
      const senderId: string = (isGroup ? ((msg as any).author || msg.from) : msg.from) as string;

      // Skip group system messages (senderId would be the group JID ending in @g.us)
      if (senderId.endsWith("@g.us") || senderId.endsWith("@broadcast")) return;

      const now = Date.now();
      const lastMsg = this.spamTracker.get(senderId) ?? 0;
      if (now - lastMsg < this.config.antiSpamDelay) {
        this.addLog("warn", `Anti-spam: ignorando ${senderId}`, senderId, isGroup);
        return;
      }
      this.spamTracker.set(senderId, now);

      const contact = await msg.getContact();
      const contactName = contact.pushname || contact.name || contact.number || senderId;

      if (isGroup) {
        const groupChat = chat as GroupChat;
        try {
          const protection = await checkProtection(msg, groupChat, senderId);
          if (protection.blocked) {
            this.addLog("warn", `🛡️ Proteção: ${protection.reason}`, contactName, true);
            const participants = groupChat.participants;
            const botParticipant = participants.find((p) => p.id.user === this.phoneNumber);
            const isBotAdmin = botParticipant?.isAdmin || false;
            await applyProtectionAction(msg, groupChat, protection, isBotAdmin);
            return;
          }
        } catch (err) {
          logger.warn({ err }, "Protection check failed");
        }

        // ── Moderação avançada (novo módulo, independente da proteção existente) ──
        try {
          const modResult = await checkModeration(msg, groupChat, senderId);
          if (modResult.violated) {
            this.addLog("warn", `🚨 Moderação: ${modResult.label}`, contactName, true);
            const participants = groupChat.participants;
            const botParticipant = participants.find((p) => p.id.user === this.phoneNumber);
            const isBotAdmin = botParticipant?.isAdmin || false;
            await applyModeration(msg, groupChat, modResult, isBotAdmin, senderId, contactName);
            return;
          }
        } catch (err) {
          logger.warn({ err }, "Moderation check failed");
        }

        const quizAnswer = checkQuizAnswer(chat.id._serialized, body);
        if (quizAnswer) {
          addXp(senderId, 50);
          await msg.reply(
            `🎉 *Correto, @${senderId.split("@")[0]}!*\nResposta: *${quizAnswer}*\n\n+50 XP bônus! 🌟`,
            undefined,
            { mentions: [senderId] },
          );
          return;
        }
      }

      const isCommand = body.startsWith(this.config.prefix);

      const ctx = {
        msg,
        chat,
        config: this.config,
        isGroup,
        contactName,
        senderId,
        addLog: this.addLog.bind(this),
      };

      // ── AutoFig: imagem → figurinha automática (antes do handler de comando) ──
      if (
        isGroup &&
        !isCommand &&
        msg.hasMedia &&
        msg.type === "image" &&
        !(msg as any).isGif
      ) {
        try {
          const grpData = getGroup(chat.id._serialized);
          if (grpData.autofig) {
            await handleAutoFig(msg, chat as GroupChat);
            return;
          }
        } catch {}
      }

      if (isCommand) {
        if (this.config.mode === "auto") return;
        this.addLog(
          "info",
          `🔧 Comando de ${contactName}${isGroup ? ` (${chat.name})` : ""}: "${body.substring(0, 80)}"`,
          contactName,
          isGroup,
        );
        await chat.sendStateTyping();
        await new Promise((r) => setTimeout(r, Math.min(this.config.responseDelay, 800)));
        await handleCommand(this.config.prefix, body, ctx);
        this.messagesHandled++;
        await chat.clearState();
        return;
      }

      if (this.config.mode === "commands") return;

      if (msg.type !== "chat" && msg.type !== ("text" as typeof msg.type)) return;
      if (!body) return;

      this.addLog(
        "info",
        `📩 Mensagem de ${contactName}${isGroup ? ` (${chat.name})` : ""}: "${body.substring(0, 80)}${body.length > 80 ? "..." : ""}"`,
        contactName,
        isGroup,
      );

      await chat.sendStateTyping();
      await new Promise((r) => setTimeout(r, this.config.responseDelay));

      const response = await generateAIResponse(
        body, contactName, isGroup ? chat.name : null,
        this.config.systemPrompt, this.config.botName,
      );

      await msg.reply(response);
      this.messagesHandled++;
      addXp(senderId, 5);

      this.addLog(
        "success",
        `✅ Resposta para ${contactName}: "${response.substring(0, 60)}${response.length > 60 ? "..." : ""}"`,
        contactName,
        isGroup,
      );
      await chat.clearState();
    } catch (err: unknown) {
      const error = err as Error;
      this.addLog("error", `Erro ao processar mensagem: ${error.message}`);
      logger.error({ err }, "Error handling message");
    }
  }

  /**
   * Reconexão forçada — chamada pelo Guardian quando detecta o bot offline.
   * Destrói o cliente atual de forma segura antes de criar um novo.
   */
  reconnect() {
    if (this.isInitializing) return; // já reconectando
    this.addLog("warn", "🔄 Reconexão forçada pelo Guardian...");
    const old = this.client;
    this.client = null;
    this.isInitializing = false;
    this.initStartedAt = null;
    // destrói em background sem bloquear
    if (old) {
      old.destroy().catch(() => {});
    }
    this.initClient();
  }

  /**
   * Reset total quando o Guardian detecta init travado por mais de 5 min.
   * Força destroy do processo puppeteer e recria o cliente do zero.
   */
  forceResetInit() {
    this.addLog("error", "⏱️ [Guardian] Init travado detectado — resetando cliente por completo...");
    const old = this.client;
    this.client = null;
    this.isInitializing = false;
    this.initStartedAt = null;
    this.state = "disconnected";
    if (old) {
      // destroy com timeout agressivo para não travar
      const killTimer = setTimeout(() => {
        logger.warn("[GUARDIAN] destroy() demorou demais — continuando mesmo assim");
      }, 10000);
      old.destroy()
        .catch(() => {})
        .finally(() => { clearTimeout(killTimer); });
    }
    // Aguarda 5s antes de tentar novamente
    setTimeout(() => this.initClient(), 5000);
  }

  /**
   * Limpa entradas antigas do spamTracker (>5 min) para evitar vazamento de memória.
   */
  cleanSpamTracker() {
    const cutoff = Date.now() - 5 * 60 * 1000; // entradas mais antigas que 5 min
    for (const [key, ts] of this.spamTracker.entries()) {
      if (ts < cutoff) this.spamTracker.delete(key);
    }
  }

  getStatus() {
    return {
      state: this.state,
      phoneNumber: this.phoneNumber,
      connectedAt: this.connectedAt,
      messagesHandled: this.messagesHandled,
      isRunning: this.state === "ready",
      isInitializing: this.isInitializing,
    };
  }

  getQr() { return { qrDataUrl: this.qrDataUrl, state: this.state }; }
  getLogs() { return { logs: this.logs }; }
  getConfig() { return this.config; }

  updateConfig(updates: Partial<BotConfig>) {
    this.config = { ...this.config, ...updates };
    this.addLog("info", "Configuração atualizada!");
    return this.config;
  }

  async disconnect() {
    if (this.client) {
      try { await this.client.destroy(); } catch {}
      this.client = null;
    }
    this.state = "disconnected";
    this.isInitializing = false;
    this.addLog("warn", "Bot desconectado manualmente.");
  }
}

export const bot = new WhatsAppBot();
