/**
 * GUARDIAN — Sistema Anti-Queda REFORÇADO do Bot MÁRIO
 *
 * Camadas de proteção:
 *  1. Handlers globais: uncaughtException / unhandledRejection → nunca mata o processo
 *  2. Watchdog rápido (45s): verifica estado do bot e força reconexão se offline
 *  3. Detector de init travado: se puppeteer travar > 5min, força reset completo
 *  4. Keep-alive duplo (2min): pinga 2 endpoints próprios para manter o Replit acordado
 *     e para o UptimeRobot sempre encontrar o servidor respondendo
 *  5. Limpeza de spamTracker: evita vazamento de memória no Map anti-spam
 *  6. Handlers de sinal SIGTERM/SIGINT: shutdown gracioso sem deixar processos órfãos
 *
 * ⚠️  Este módulo NUNCA modifica a lógica de mensagens ou comandos existente.
 *     Apenas observa o estado e aciona reconexão quando necessário.
 */

import { logger } from "../lib/logger";

// ── tipos mínimos que precisamos do bot ──────────────────────────────────────
interface BotLike {
  getStatus(): { state: string; isRunning: boolean; isInitializing?: boolean };
  addLog(level: "info" | "warn" | "error" | "success", msg: string): void;
  reconnect?(): void;
  forceResetInit?(): void;   // reset quando init trava
  cleanSpamTracker?(): void; // limpeza periódica do Map anti-spam
}

// ── estado interno do guardian ───────────────────────────────────────────────
let botRef: BotLike | null = null;
let watchdogTimer: ReturnType<typeof setInterval> | null = null;
let keepAliveTimer: ReturnType<typeof setInterval> | null = null;
let spamCleanTimer: ReturnType<typeof setInterval> | null = null;
let consecutiveFails = 0;
let initStuckSince: number | null = null;

const MAX_CONSECUTIVE_FAILS = 4;
const WATCHDOG_INTERVAL_MS = 45 * 1000;          // 45 segundos
const KEEPALIVE_INTERVAL_MS = 2 * 60 * 1000;     // 2 minutos
const SPAM_CLEAN_INTERVAL_MS = 10 * 60 * 1000;   // 10 minutos
const STUCK_INIT_TIMEOUT_MS  = 5 * 60 * 1000;    // 5 minutos parado = travado

// ── 1. Capturadores de erro global ───────────────────────────────────────────
function installGlobalHandlers() {
  process.on("uncaughtException", (err: Error) => {
    logger.error({ err }, "⚠️  [GUARDIAN] uncaughtException interceptado — processo mantido vivo");
    botRef?.addLog("error", `⚠️ Erro não capturado interceptado: ${err.message}`);
    // NÃO chamamos process.exit — mantemos o servidor de pé
  });

  process.on("unhandledRejection", (reason: unknown) => {
    const msg = reason instanceof Error ? reason.message : String(reason);
    logger.error({ reason }, "⚠️  [GUARDIAN] unhandledRejection interceptado — processo mantido vivo");
    botRef?.addLog("warn", `⚠️ Promise rejeitada sem handler: ${msg}`);
  });

  // Shutdown gracioso: destrói cliente WA antes de sair
  const gracefulShutdown = (signal: string) => {
    logger.info(`[GUARDIAN] ${signal} recebido — encerrando graciosamente...`);
    stopGuardian();
    setTimeout(() => process.exit(0), 3000);
  };

  process.once("SIGTERM", () => gracefulShutdown("SIGTERM"));
  process.once("SIGINT",  () => gracefulShutdown("SIGINT"));

  logger.info("[GUARDIAN] Handlers de erro global + sinais instalados ✅");
}

// ── 2. Watchdog rápido + detector de init travado ────────────────────────────
function startWatchdog() {
  if (watchdogTimer) clearInterval(watchdogTimer);

  watchdogTimer = setInterval(() => {
    if (!botRef) return;

    const status = botRef.getStatus();
    const { state, isRunning, isInitializing } = status as {
      state: string; isRunning: boolean; isInitializing?: boolean;
    };

    // ── Detecção de init travado ──────────────────────────────────────────
    if (isInitializing) {
      if (initStuckSince === null) {
        initStuckSince = Date.now();
      } else if (Date.now() - initStuckSince > STUCK_INIT_TIMEOUT_MS) {
        logger.warn("[GUARDIAN] Init travado há mais de 5 min — forçando reset completo");
        botRef.addLog("error", "⏱️ [Guardian] Init do WhatsApp travou — forçando reinício do cliente...");
        initStuckSince = null;
        try { botRef.forceResetInit?.(); } catch (err) {
          logger.error({ err }, "[GUARDIAN] Erro ao forçar reset de init");
        }
        return;
      }
    } else {
      initStuckSince = null; // bot não está mais inicializando, limpa o timestamp
    }

    // ── Bot ok — zera contador ────────────────────────────────────────────
    if (isRunning && state === "ready") {
      consecutiveFails = 0;
      return;
    }

    // ── Bot fora do ar mas ainda inicializando (normal) ───────────────────
    if (isInitializing) return; // deixa o init terminar

    // ── Bot offline sem estar inicializando ───────────────────────────────
    consecutiveFails++;
    logger.warn(
      { state, consecutiveFails },
      `[GUARDIAN] Bot fora do ar (estado: ${state}) — falha ${consecutiveFails}/${MAX_CONSECUTIVE_FAILS}`,
    );
    botRef.addLog(
      "warn",
      `🔄 [Guardian] Bot offline (${state}). Reconectando... (${consecutiveFails}/${MAX_CONSECUTIVE_FAILS})`,
    );

    if (consecutiveFails > MAX_CONSECUTIVE_FAILS) {
      logger.warn("[GUARDIAN] Muitas falhas seguidas — aguardando 1 ciclo extra antes de tentar novamente");
      consecutiveFails = 0;
      return;
    }

    try {
      botRef.reconnect?.();
    } catch (err) {
      logger.error({ err }, "[GUARDIAN] Erro ao acionar reconexão");
    }
  }, WATCHDOG_INTERVAL_MS);

  logger.info(`[GUARDIAN] Watchdog iniciado — verificação a cada ${WATCHDOG_INTERVAL_MS / 1000}s ✅`);
}

// ── 3. Keep-alive (anti-sleep Replit + UptimeRobot sempre encontra servidor) ─
async function pingEndpoint(port: string, path: string): Promise<void> {
  const http = await import("http");
  return new Promise<void>((resolve) => {
    const req = http.get(`http://localhost:${port}${path}`, (res) => {
      res.resume(); // descarta body
      resolve();
    });
    req.on("error", () => resolve()); // ignora erros de rede
    req.setTimeout(8000, () => { req.destroy(); resolve(); });
  });
}

async function pingself() {
  try {
    const port = process.env["PORT"] ?? "8080";
    // Pinga dois endpoints para garantir que o servidor continua respondendo
    await Promise.allSettled([
      pingEndpoint(port, "/api/ping"),
      pingEndpoint(port, "/api/bot/status"),
    ]);
    logger.info("[GUARDIAN] Keep-alive ping duplo OK ✅");
  } catch {
    // silencioso — não deve travar nada
  }
}

function startKeepAlive() {
  if (keepAliveTimer) clearInterval(keepAliveTimer);

  // Pinga imediatamente ao iniciar (não espera o primeiro intervalo)
  void pingself();

  keepAliveTimer = setInterval(pingself, KEEPALIVE_INTERVAL_MS);

  logger.info(`[GUARDIAN] Keep-alive iniciado — ping duplo a cada ${KEEPALIVE_INTERVAL_MS / 1000}s ✅`);
}

// ── 4. Limpeza periódica do spamTracker ──────────────────────────────────────
function startSpamClean() {
  if (spamCleanTimer) clearInterval(spamCleanTimer);

  spamCleanTimer = setInterval(() => {
    try {
      botRef?.cleanSpamTracker?.();
      logger.info("[GUARDIAN] spamTracker limpo ✅");
    } catch (err) {
      logger.warn({ err }, "[GUARDIAN] Erro ao limpar spamTracker");
    }
  }, SPAM_CLEAN_INTERVAL_MS);

  logger.info(`[GUARDIAN] Limpeza de spam iniciada — a cada ${SPAM_CLEAN_INTERVAL_MS / 1000}s ✅`);
}

// ── API pública ──────────────────────────────────────────────────────────────

/**
 * Inicializa o Guardian. Pode ser chamado assim que o bot é criado
 * (não precisa esperar o estado "ready").
 */
export function startGuardian(bot: BotLike) {
  if (botRef) return; // já iniciado — não duplicar
  botRef = bot;

  installGlobalHandlers();
  startWatchdog();
  startKeepAlive();
  startSpamClean();

  logger.info("🛡️  [GUARDIAN] Sistema anti-queda REFORÇADO ATIVO ✅");
  bot.addLog("success", "🛡️ Guardian anti-queda REFORÇADO iniciado! Bot protegido em múltiplas camadas.");
}

/**
 * Para todos os timers (útil em shutdown controlado).
 */
export function stopGuardian() {
  if (watchdogTimer)  { clearInterval(watchdogTimer);  watchdogTimer  = null; }
  if (keepAliveTimer) { clearInterval(keepAliveTimer); keepAliveTimer = null; }
  if (spamCleanTimer) { clearInterval(spamCleanTimer); spamCleanTimer = null; }
  botRef = null;
  logger.info("[GUARDIAN] Parado.");
}
