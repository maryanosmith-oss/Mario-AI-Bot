import { Message, MessageMedia } from "whatsapp-web.js";

export async function revelarViewOnce(msg: Message): Promise<string | null> {
  // O comando !vv exige que o usuário responda (quote) a mensagem view-once
  if (!msg.hasQuotedMsg) {
    return "❌ Responda a uma mensagem de *visualização única* e use *!vv*!";
  }

  let quoted: Message;
  try {
    quoted = await msg.getQuotedMessage();
  } catch {
    return "❌ Não consegui acessar a mensagem citada!";
  }

  // Verificar se é view once (vários formatos possíveis no whatsapp-web.js)
  const rawData: any = (quoted as any)._data ?? {};
  const msgContent: any =
    rawData.message ??
    rawData.viewOnceMessage?.message ??
    rawData.viewOnceMessageV2?.message ??
    rawData.viewOnceMessageV2Extension?.message ??
    {};

  const isViewOnce: boolean =
    rawData.isViewOnce === true ||
    !!rawData.viewOnceMessage ||
    !!rawData.viewOnceMessageV2 ||
    !!rawData.viewOnceMessageV2Extension ||
    !!(msgContent.imageMessage?.viewOnce) ||
    !!(msgContent.videoMessage?.viewOnce);

  // Aceitar também se simplesmente tem mídia e não é view-once confirmado
  // (para compatibilidade com diferentes versões)
  const hasMedia = quoted.hasMedia || !!(msgContent.imageMessage || msgContent.videoMessage || msgContent.audioMessage);

  if (!hasMedia) {
    return "❌ A mensagem citada não contém mídia!";
  }

  if (!isViewOnce && !hasMedia) {
    return "⚠️ Esta mensagem não parece ser de *visualização única*!";
  }

  try {
    let media: MessageMedia | null = null;

    // Tentar baixar diretamente do objeto quoted
    try {
      media = await quoted.downloadMedia();
    } catch {}

    if (!media) {
      return "❌ Não consegui baixar a mídia. A mensagem pode ter expirado!";
    }

    const tipo = media.mimetype?.startsWith("video") ? "video" :
                 media.mimetype?.startsWith("audio") ? "audio" : "imagem";

    // Re-enviar como mídia normal (sem flag de view-once)
    const chat = await msg.getChat();
    await chat.sendMessage(media, {
      caption: `🔓 *Mídia revelada!* (${tipo}) — via *!vv*`,
    });

    return null; // null = já enviou, não precisa de reply texto
  } catch (err: any) {
    return `❌ Erro ao revelar mídia: ${err?.message ?? "desconhecido"}`;
  }
}
